<?php
/**
 * Services page template.
 */
get_header();

if ( have_posts() ) :
    the_post();
    $elementor_data = json_decode( get_post_meta( get_the_ID(), '_elementor_data', true ), true );
    if (
        'builder' === get_post_meta( get_the_ID(), '_elementor_edit_mode', true )
        && is_array( $elementor_data )
        && ! empty( $elementor_data )
    ) :
        ?>
        <main class="elementor-page-content">
            <?php the_content(); ?>
        </main>
        <?php
        get_footer();
        return;
    endif;
    rewind_posts();
endif;

$services = array(
    'construction_plan' => array(
        'title'       => __( 'Construction Plan', 'construction-theme' ),
        'description' => __( 'Clear project planning and staged execution to keep your build organised, efficient, and aligned with your goals.', 'construction-theme' ),
        'items'       => array(
            __( 'Project scope and planning', 'construction-theme' ),
            __( 'Timeline and build sequencing', 'construction-theme' ),
            __( 'Execution oversight and coordination', 'construction-theme' ),
        ),
    ),
    'project_execution' => array(
        'title'       => __( 'Project Execution', 'construction-theme' ),
        'description' => __( 'End-to-end project execution with skilled teams, clear coordination, and quality checks throughout construction.', 'construction-theme' ),
        'items'       => array(
            __( 'On-site construction and supervision', 'construction-theme' ),
            __( 'Trade and material coordination', 'construction-theme' ),
            __( 'Progress and quality checks', 'construction-theme' ),
        ),
    ),
    'design_surveying' => array(
        'title'       => __( 'Design Surveying', 'construction-theme' ),
        'description' => __( 'Detailed site and design surveying that informs precise decisions, safe construction, and better project outcomes.', 'construction-theme' ),
        'items'       => array(
            __( 'Land and site assessment', 'construction-theme' ),
            __( 'Measurement and layout verification', 'construction-theme' ),
            __( 'Feasibility and planning support', 'construction-theme' ),
        ),
    ),
    'interior_design' => array(
        'title'       => __( 'Interior Design', 'construction-theme' ),
        'description' => __( 'Functional, elegant interiors planned around the way you live and work, with finishes that feel personal and practical.', 'construction-theme' ),
        'items'       => array(
            __( 'Layout and functional planning', 'construction-theme' ),
            __( 'Lighting, finishes, and material selection', 'construction-theme' ),
            __( 'Styling and detail coordination', 'construction-theme' ),
        ),
    ),
    'landscaping_services' => array(
        'title'       => __( 'Landscaping Services', 'construction-theme' ),
        'description' => __( 'Thoughtful outdoor spaces designed to improve value, comfort, and visual appeal while matching your property.', 'construction-theme' ),
        'items'       => array(
            __( 'Outdoor design and planning', 'construction-theme' ),
            __( 'Garden and hardscape installation', 'construction-theme' ),
            __( 'Planting and finishing touches', 'construction-theme' ),
        ),
    ),
    'plan_estimation' => array(
        'title'       => __( 'Plan Estimation', 'construction-theme' ),
        'description' => __( 'Accurate cost planning and quantity estimates to help you budget confidently before construction begins.', 'construction-theme' ),
        'items'       => array(
            __( 'Material and labour estimates', 'construction-theme' ),
            __( 'Budget forecasting and planning', 'construction-theme' ),
            __( 'Transparent cost review', 'construction-theme' ),
        ),
    ),
);
?>
<main class="services-page">
    <section class="services-page-hero">
        <div class="container">
            <p class="services-page-kicker"><?php esc_html_e( 'What We Do', 'construction-theme' ); ?></p>
            <h1><?php esc_html_e( 'Our Construction Services', 'construction-theme' ); ?></h1>
            <p><?php esc_html_e( 'From the first design conversation to the finishing touches, we bring the people, planning, and workmanship together to deliver your project with confidence.', 'construction-theme' ); ?></p>
            <a class="services-page-button" href="<?php echo esc_url( home_url( '/#enquiry-section' ) ); ?>"><?php esc_html_e( 'Discuss Your Project', 'construction-theme' ); ?></a>
        </div>
    </section>
    <section class="services-page-list">
        <div class="container">
            <div class="services-page-intro">
                <p class="services-page-kicker"><?php esc_html_e( 'Built Around Your Project', 'construction-theme' ); ?></p>
                <h2><?php esc_html_e( 'A reliable team for every stage', 'construction-theme' ); ?></h2>
                <p><?php esc_html_e( 'Choose a service on its own or bring the full team together. We tailor our work to your goals, site, schedule, and budget.', 'construction-theme' ); ?></p>
            </div>
            <div class="services-page-grid">
                <?php foreach ( $services as $key => $service ) : ?>
                    <?php
                    $title       = get_theme_mod( "construction_service_title_$key", $service['title'] );
                    $icon        = get_theme_mod( "construction_service_icon_$key" );
                    $service_id  = sanitize_html_class( $key );
                    ?>
                    <article class="services-page-card" id="<?php echo esc_attr( $service_id ); ?>">
                        <?php if ( $icon ) : ?>
                            <img src="<?php echo esc_url( $icon ); ?>" alt="" class="services-page-icon" />
                        <?php else : ?>
                            <span class="services-page-number" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', array_search( $key, array_keys( $services ), true ) + 1 ) ); ?></span>
                        <?php endif; ?>
                        <h2><?php echo esc_html( $title ); ?></h2>
                        <p><?php echo esc_html( $service['description'] ); ?></p>
                        <ul class="services-page-includes">
                            <?php foreach ( $service['items'] as $item ) : ?>
                                <li><?php echo esc_html( $item ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <a class="services-page-text-link" href="<?php echo esc_url( home_url( '/#enquiry-section' ) ); ?>"><?php esc_html_e( 'Ask about this service', 'construction-theme' ); ?><span aria-hidden="true"> →</span></a>
                    </article>
                <?php endforeach; ?>
            </div>
            <div class="services-page-process">
                <div>
                    <p class="services-page-kicker"><?php esc_html_e( 'How We Work', 'construction-theme' ); ?></p>
                    <h2><?php esc_html_e( 'A clear path from idea to handover', 'construction-theme' ); ?></h2>
                    <p><?php esc_html_e( 'You will know what comes next, who is responsible, and how decisions affect the project.', 'construction-theme' ); ?></p>
                </div>
                <ol>
                    <li><span>01</span><div><h3><?php esc_html_e( 'Tell us about your project', 'construction-theme' ); ?></h3><p><?php esc_html_e( 'We learn about your needs, site, priorities, and budget.', 'construction-theme' ); ?></p></div></li>
                    <li><span>02</span><div><h3><?php esc_html_e( 'Plan the right approach', 'construction-theme' ); ?></h3><p><?php esc_html_e( 'We agree the scope, design direction, timing, and next steps.', 'construction-theme' ); ?></p></div></li>
                    <li><span>03</span><div><h3><?php esc_html_e( 'Build with confidence', 'construction-theme' ); ?></h3><p><?php esc_html_e( 'Our team coordinates the work and keeps you informed through completion.', 'construction-theme' ); ?></p></div></li>
                </ol>
            </div>
            <div class="services-page-cta">
                <h2><?php esc_html_e( 'Planning a project?', 'construction-theme' ); ?></h2>
                <p><?php esc_html_e( 'Tell us what you have in mind and our team will be happy to help.', 'construction-theme' ); ?></p>
                <a class="services-page-button" href="<?php echo esc_url( home_url( '/#enquiry-section' ) ); ?>"><?php esc_html_e( 'Request an Enquiry', 'construction-theme' ); ?></a>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
