// assets/js/theme.js
document.addEventListener('DOMContentLoaded', function () {
    // Reveal built-in content as it enters view without hiding it when scripts fail.
    var revealItems = document.querySelectorAll(
        '.construction-home .about-image, .construction-home .about-text, ' +
        '.construction-home .service-card, .construction-home .stat-item, ' +
        '.construction-home .project-card, .construction-home .testimonial-slider, ' +
        '.construction-map-section .construction-map-frame, .services-page-card, ' +
        '.services-page-process, .services-page-cta'
    );
    if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        var revealObserver = new IntersectionObserver(function (entries, observer) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });

        revealItems.forEach(function (item) {
            item.classList.add('reveal-on-scroll');
            revealObserver.observe(item);
        });
    }

    // Mobile menu toggle
    var toggle = document.querySelector('.mobile-menu-toggle');
    var nav = document.querySelector('.main-navigation');
    if (toggle && nav) {
        var toggleIcon = toggle.querySelector('[aria-hidden="true"]');
        var mobileMenuQuery = window.matchMedia('(max-width: 1024px)');
        var setMenuExpanded = function (expanded) {
            toggle.setAttribute('aria-expanded', String(expanded));
            toggle.setAttribute('aria-label', expanded ? 'Close navigation menu' : 'Open navigation menu');
            nav.classList.toggle('active', expanded && mobileMenuQuery.matches);
            if (toggleIcon) {
                toggleIcon.textContent = expanded ? '×' : '☰';
            }
        };

        toggle.addEventListener('click', function () {
            setMenuExpanded(this.getAttribute('aria-expanded') !== 'true');
        });
        nav.addEventListener('click', function (event) {
            if (event.target.closest('a')) {
                setMenuExpanded(false);
            }
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && nav.classList.contains('active')) {
                setMenuExpanded(false);
                toggle.focus();
            }
        });
        var resetMenuOnDesktop = function (event) {
            if (!event.matches) {
                setMenuExpanded(false);
            }
        };
        if (mobileMenuQuery.addEventListener) {
            mobileMenuQuery.addEventListener('change', resetMenuOnDesktop);
        } else if (mobileMenuQuery.addListener) {
            mobileMenuQuery.addListener(resetMenuOnDesktop);
        }
    }
    // Hero slider autoplay
    var heroSlider = document.getElementById('hero-slider');
    if (heroSlider) {
        var slides = heroSlider.querySelectorAll('.hero-slide');
        var current = 0;
        var showSlide = function (index) {
            slides.forEach(function (slide, i) {
                slide.classList.toggle('active', i === index);
            });
        };
        setInterval(function () {
            current = (current + 1) % slides.length;
            showSlide(current);
        }, 5000);
    }
    // Testimonial slider navigation
    var testimonialSlider = document.getElementById('testimonial-slider');
    if (testimonialSlider) {
        var items = testimonialSlider.querySelectorAll('.testimonial-item');
        var currentTest = 0;
        var showTest = function (index) {
            items.forEach(function (item, i) {
                item.classList.toggle('active', i === index);
            });
        };
        var prevBtn = testimonialSlider.querySelector('.prev-testimonial');
        var nextBtn = testimonialSlider.querySelector('.next-testimonial');
        if (prevBtn) {
            prevBtn.addEventListener('click', function () {
                currentTest = (currentTest - 1 + items.length) % items.length;
                showTest(currentTest);
            });
        }
        if (nextBtn) {
            nextBtn.addEventListener('click', function () {
                currentTest = (currentTest + 1) % items.length;
                showTest(currentTest);
            });
        }
    }
    // Enquiry form AJAX submit
    var enquiryForm = document.getElementById('enquiry-form');
    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var formData = new FormData(enquiryForm);
            var whatsappNumber = enquiryForm.getAttribute('data-whatsapp-number');
            var whatsappNotice = '';
            if (whatsappNumber) {
                var whatsappMessage = [
                    'New enquiry',
                    'Name: ' + formData.get('name'),
                    'Email: ' + formData.get('email'),
                    formData.get('phone') ? 'Phone: ' + formData.get('phone') : '',
                    'Message: ' + formData.get('message')
                ].filter(Boolean).join('\n');
                var whatsappWindow = window.open(
                    'https://wa.me/' + whatsappNumber + '?text=' + encodeURIComponent(whatsappMessage),
                    '_blank'
                );
                if (whatsappWindow) {
                    whatsappWindow.opener = null;
                } else {
                    whatsappNotice = ' Allow pop-ups to open WhatsApp with your enquiry.';
                }
            } else {
                whatsappNotice = ' WhatsApp is not configured. Add a WhatsApp number or business phone under Appearance → Customize → Contact Details.';
            }
            var xhr = new XMLHttpRequest();
            xhr.open('POST', enquiryForm.action, true);
            xhr.onload = function () {
                var respDiv = document.getElementById('enquiry-response');
                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        respDiv.innerHTML = '<p style="color:green;">' + res.data.message + '</p>' +
                            (whatsappNotice ? '<p style="color:#b45309;">' + whatsappNotice + '</p>' : '');
                        enquiryForm.reset();
                    } else {
                        respDiv.innerHTML = '<p style="color:red;">' + res.data.message + '</p>' +
                            (whatsappNotice ? '<p style="color:#b45309;">' + whatsappNotice + '</p>' : '');
                    }
                } catch (err) {
                    respDiv.innerHTML = '<p style="color:red;">' + err.message + '</p>';
                }
            };
            xhr.send(formData);
        });
    }
});
