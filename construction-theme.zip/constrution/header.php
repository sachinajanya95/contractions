<?php
/**
 * Header template
 */
$header_cta_label = get_theme_mod( 'construction_header_cta_label', __( 'Enquiry Now', 'construction-theme' ) );
$header_cta_url   = get_theme_mod( 'construction_header_cta_url', home_url( '/#enquiry-section' ) );
if ( is_string( $header_cta_url ) && isset( $header_cta_url[0] ) && '#' === $header_cta_url[0] ) {
    $header_cta_url = home_url( '/' . $header_cta_url );
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="container">
        <div class="site-branding">
            <?php
            if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
                the_custom_logo();
            } else {
                echo '<a href="' . esc_url( home_url( '/' ) ) . '"><h1 class="site-title">' . get_bloginfo( 'name' ) . '</h1></a>';
            }
            ?>
        </div>
        <button class="mobile-menu-toggle" type="button" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation menu', 'construction-theme' ); ?>">
            <span aria-hidden="true">&#9776;</span>
        </button>
        <?php
        wp_nav_menu( array(
            'theme_location' => 'primary',
            'menu_id'        => 'primary-menu',
            'container'      => 'nav',
            'container_class'=> 'main-navigation',
            'fallback_cb'    => 'construction_primary_menu_fallback',
        ) );
        ?>
        <?php if ( $header_cta_label ) : ?>
            <a href="<?php echo esc_url( $header_cta_url ); ?>" class="enquiry-btn"><?php echo esc_html( $header_cta_label ); ?></a>
        <?php endif; ?>
    </div>
</header>
